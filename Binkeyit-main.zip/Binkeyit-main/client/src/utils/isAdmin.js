const isAdmin = (s) => {
  if (s === "ADMIN") {
    return true;
  }

  return false;
};

export default isAdmin;
