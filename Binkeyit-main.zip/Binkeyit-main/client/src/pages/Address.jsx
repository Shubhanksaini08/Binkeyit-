import React from 'react'

const Address = () => {
  return (
    <div>Address</div>
  )
}

export default Address